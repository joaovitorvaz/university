{-# OPTIONS_GHC -Wall #-}

module TextStats where

import Prelude hiding (words, lines, Word)
import Data.Char

----------------------------------------
-- types for the text statistics tool --
----------------------------------------

-- text representation

type Text = [Paragraph]

type Paragraph = [Line]

type Line = [Word]

type Word = (String, Int)

-- word frequency table

type Table = [(String,Int)]


-- MARCUS VINÍCIUS SOUZA FERNANDES
-- 19.1.4046

----------------------------------------
-- Parte 1                            --
----------------------------------------

-- Exercício 1.

-- Neste exercício não obtive dificuldades, basicamente
-- utilzei da função filter juntamente da condição criada
-- que descnsidera os digitos presentes na string.
--
-- Conversei com o aluno Felipe Ramos sobre esta questão
-- o mesmo compartilhou que existe um comando bem simples
-- que pouparia esforço "isPontuation", achei bem mais
-- relevante mas preferi manter meu código, uma vez que é
-- funcional e eu compreendi o intuito da questão.


removePunct :: String -> String
removePunct s = filter condition s
          where
             condition = (\x -> x /= '.' && x /= '!' && x /= '?' && x /= ',' && x /= '-')

-- Exercício 2.

-- Neste exercício fiquei bastante tempo trabalhando nele.
-- Tentei realizar apenas com uma função e um foldr dentro
-- do outro, porém não obtive sucesso e começou a ficar
-- estressante. Decidi criar funções auxiliares e utilizar o foldr
-- em ao menos uma delas.
-- Inicialmente eu identifico os espaços e separo a string em uma lista
-- de strings, se encerrando ao encontrar um novo espaço.
-- Utilizei esta mesma função para o desenvolvimento da lista de número 4.
-- Durante o desenvolvimento das listas eu não estava compreendendo bem
-- o uso do foldr porém com o auxilio do aluno Luka, as dúvidas do alunos
-- sanadas no Slack e alguns códigos no Stack Overflow, pude entender.

words :: String -> [Word]
words s = numberLetters (removeSpc s)

removeSpc :: String -> [String]
removeSpc s = foldr (\c (x:xs) -> if c == ' ' then "":x:xs else (c:x):xs) [""] (removePunct s)

numberLetters :: [String] -> [Word]
numberLetters [] = []
numberLetters (x:xs)
                   | length x > 3 = (x, length x) : numberLetters xs
                   | otherwise = numberLetters xs

-- Exercício 3.

-- Realizei este exercício com muita agilidade, utilizei da mesma
-- lógica da questão anterior e pude reaproveitar parte do código.

lines :: String -> [String]
lines "" = []
lines t = removeBarN t

removeBarN :: String -> [String]
removeBarN s = foldr (\c (x:xs) -> if c == '\n' then "":x:xs else (c:x):xs) [""] s

-- Exercício 4.

-- Este exercício ao meu ver foi o mais desafiador, não obtive sucesso,
-- porém deixei um trecho do código desenvolvido comentado abaixo!
-- O aluno Luka, me auxiliou com algumas idéias mas os erros foram constantes.
-- Perdi muito tempo lidando com a questão e preferi seguir a diante.
-- Sinto dificuldade ao gerar uma lista de listas, preciso trabalhar mais nisso,
-- não encontrei um conteúdo que me fizesse sentido, sei que não é algo tão complexo.

paragraphs :: String -> [[String]]
paragraphs = undefined

--paragraphs :: String -> [[String]]
--paragraphs s = createParagraph (lines s)

--createParagraph :: [String] -> [String]
--createParagragh [] = []
--createParagragh (x:xs) = foldr (\c (x:xs) -> if c == "" then [""]:x:xs else (c:x):xs) [""] s

-- Exercício 5.

-- Devido a ausência do código anterior, não consegui prosseguir com esta questão.

buildText :: String -> Text
buildText
    = undefined

----------------------------------------
-- Parte 2                            --
----------------------------------------

-- Exercício 6.

-- Acredito que segui o caminho mais longo ao desenvolver esta questão, posso afirmar questão
-- todos os casos que testei foram efetivos. Este exercicio tambem foi bem desafiador,
-- depois de horas tentando desenvolver algo eu preferi dividir o raciocíneo em etapas.
-- Tornando assim o código bem mais extenso e talvez sem tanta necessidade.

-- Inicialmente eu recebo uma linha, e realizado algumas ações.

-- 1° Comparo as repetições presentes e retorno uma linha com todas elas
-- 2° Conto as repetições desta mesma linha e retorno a palavra e o número de repetições
-- 3° Uno todo esse processo com um passo recursivo
-- 4° Ordeno com a utilização do quicksort (Código obtivo no livro disponbilizado para a disciplina)
-- Devido a não exclusão das tuplas na lista, eu pensei em ordenar para que o valor interessante de cada repetição
-- se encontre na ultima posição do trecho. Ex: Entrada : [("a",1), ("a",1), ("a",1)] Saida: [("a",1), ("a",2), ("a",3)]
-- 5° Removo os repetidos (conservando o último do trecho de repetição).

-- Como disse, provavelmente, há uma forma bem mais simples e eficaz, menos custosa
-- tambem, porém esta foi a forma mais viável que pude encontrar para reaproveitar
-- todo o código que havia tentando implementar ao longo de horas.

line2Table :: Line -> Table
line2Table [] = []
line2Table (x:xs) = removeRepeat (quicksort (preList (x:xs)))

removeRepeat :: Line -> Table
removeRepeat [] = []
removeRepeat [x] = [x]
removeRepeat (x:xs)
                  | fst x == fst (head xs) = removeRepeat xs
                  | otherwise = x : removeRepeat xs

preList :: Line -> Line
preList [] = []
preList (x:xs) = countRepeat (compareRepeat (x:xs)) : preList xs

compareRepeat :: Line -> Line
compareRepeat [] = []
compareRepeat (x:xs) = filter (==x) (x:xs)

countRepeat :: Line -> Word
countRepeat [] = ("",0)
countRepeat (x:xs) = (fst x, length (x:xs))

quicksort :: Ord a => [a] -> [a]
quicksort [] = []
quicksort (x:xs) =
    let smallerSorted = quicksort [a | a <- xs, a <= x]
        biggerSorted = quicksort [a | a <- xs, a > x]
    in  smallerSorted ++ [x] ++ biggerSorted


-- Exercício 7.

-- Esta questão tambem foi bem desafiadora, devido a "bagunça" de minha questão
-- anterior, ficou bem mais complexo realizar um código limpo para esta questão.

-- Confesso que ela apresenta erros mas foi o mais longe que consegui executar.

-- Utilizei o mesmo raciocíneo da questão anterior e aproveiei alguns trechos
-- de código.

union :: Table -> Table -> Table
union x [] = x
union [] y = y
union x y = removeRepeat' (removeRepeat' (somRepeat (quicksort (x ++ y)) 0))

somRepeat :: Line -> Int -> Table
somRepeat [] _ = []
somRepeat [x] _ = [x]
somRepeat (x:xs) n
                 | fst x == fst (head xs) = (fst (head xs), (snd x) + ((snd (head xs)) - n)) : somRepeat xs (snd (head xs))
                 | otherwise = x : somRepeat xs 0

removeRepeat' :: Line -> Table
removeRepeat' [] = []
removeRepeat' [x] = [x]
removeRepeat' (x:xs)
                 | fst x == fst (head xs) = removeRepeat' xs
                 | otherwise = x : removeRepeat' xs

-- Exercício 8.

-- Não consegui executar esta questão.

paragraph2Table :: Paragraph -> Table
paragraph2Table = undefined

-- Exercício 9.

-- Não consegui executar esta questão.

mkTable :: Text -> Table
mkTable = undefined

-- Exercício 10.

-- Cheguei a este raciocíneo durante uma conversa com o aluno Felipe Ramos
-- ficamos um pouco confusos ao aprofundar nas listas, percorrendo as cabeças
-- e inserindo o length para contar o número de elementos desejado.
-- Mas após alguns testes de mesa (rabiscando no caderno), tudo fez mais sentido.

-- O trabalho foi basicamente contar o número de palavras de cada paragrafo e
-- utilizar este somatório para que dividido com o número de paragrafos, forneça a média.

numWordsPar :: Paragraph -> Double
numWordsPar [] = 0
numWordsPar (x:xs) = fromIntegral (length x) + (numWordsPar xs)

wordAverage :: Text -> Double
wordAverage [] = 0
wordAverage (x:xs) = (sum [numWordsPar y | y <- (x:xs)]) / fromIntegral (length (x:xs))

-- Exercício 11.

-- Esta questão é bem semelhante com a anterior, utilizei um raciocíneo semelhante
-- a questão anterior, porém adaptado para contar as linhas e realizar a média de tal.

lineAverage :: Text -> Double
lineAverage [] = 0
lineAverage (x:xs) = fromIntegral (sum [length y | y <- (x:xs)]) / fromIntegral (length (x:xs))

-- Exercício 12.

-- Cheguei no raciocíneo desta questão durante uma conversa com o Aluno Felipe representaremos
-- inicialmente estavamos pensando em algo bem mais complexo, porém foi notado que era apenas
-- passar a string, chamando a sua calda recursivamente até chegar (ou não) em um conteúdo que poderia
-- se assemelhar ao sufixo de entrada.

isSuffix :: String -> String -> Bool
isSuffix _ [] = False
isSuffix [] _ = False
isSuffix (x:xs) (y:ys)
                     | (x:xs) /= (y:ys) = isSuffix (x:xs) ys
                     | otherwise = True

-- Exercício 13.

-- Este exercício foi bem interessante, inicialmente aloquei uma lista para facilitar
-- o desenvolvimento. Basicamente passei a cabeça da Table para a função auxiliar que
-- chama a função isSuffix n vezes para cada palavra passando todos os elementos da lista
-- previamente alocada para comparacção. Com isso, realizei chamadas recursivas até chegar
-- ao caso base.

pobre :: [String]
pobre = ["ão","ar","esa","eza","or","dor","ado","ou","oso"]

poorTable :: Table -> Table
poorTable [] = []
poorTable (x:xs)
               | isPobre x pobre == True = x : poorTable xs
               | otherwise = poorTable xs

isPobre :: Word -> [String] -> Bool
isPobre _ [] = False
isPobre x (y:ys)
               | isSuffix y (fst x) == True = True
               | otherwise = isPobre x ys


----------------------------------------
-- Parte 3                            --
----------------------------------------

-- Exercício 14.

-- Inicialmente fiquei confuso com o enunciado porém o aluno Arilton
-- esclareceu algumas dúvidas no grupo de whatsapp da turma.
-- O que fiz foi didvir a lista de tuplas, respectivamente em palavras e digitos,
-- porém a divisão foi feita convertendo seus tipos inteiros e formando uma lista.
-- Nas strings trabalhei com o length e já com os digitos, os transformei em strings
-- e em seguida apliquei o length sobre cada item.
-- Com isso, obtive duas lista e extrai o maior valor de cada para retornar na tupla de
-- inteiros.

columnsSize :: Table -> (Int,Int)
columnsSize [] = (0,0)
columnsSize x = (maiorOfAll (listaTamanhos x), maiorOfAll (listaDigitos x))

listaTamanhos :: Table -> [Int]
listaTamanhos [] = []
listaTamanhos (x:xs) = length (fst x) : (listaTamanhos xs)

listaDigitos :: Table -> [Int]
listaDigitos [] = []
listaDigitos (x:xs) = (length (show (snd x))) : (listaDigitos xs)

maiorOfAll :: [Int] -> Int
maiorOfAll [] = 0
maiorOfAll (x:xs) = max x (maiorOfAll xs)

-- Exercício 15.

-- Inicialmente fiquei um pouco confuso ao ler o exemplo do enunciado,
-- acredito que interpretei da forma correta.
-- Inicialmente criei uma variavel para facilitar meu trabalho e deixar
-- o código mais limpo, com isso realizei a comparação necessária e evidenciei
-- os dois casos, sendo o interessante, a realização da concatenação da string
-- com a repetição de "t" vezes o espaço vazio.

-- A função replicate foi bem útil neste exercicio, recordei da mesma devido a
-- seu uso na lista de exercícios.

complete :: Int -> String -> String
complete _ [] = []
complete 0 x = x
complete n (x:xs) = let t = n - (length (x:xs)) in
                          if t <= 0 then (x:xs)
                          else (x:xs) ++ (replicate t ' ')

-- Exercício 16.

-- Pude compreender melhor as questões [16 .. 19] com o auxílio do aluno
-- Arilton, me senti confuso nos enunciados. O desenvolvimento delas foi bem ágil,
-- basicamente utilizei a função replicate para efetivar as repetições essenciais e
-- concatenei as repetições junto aos ['\n'] e palavras estáticas. Após feito, realizei alguns
-- cuidados de formatação.

header :: (Int, Int) -> String
header (x,y) = (replicate (x+y+3) '-') ++ ['\n'] ++ (complete (x) "Palavra") ++ (complete (y+3) "Freq.") ++ ['\n'] ++ (replicate (x+y+3) '-') ++ ['\n']

-- Exercício 17.

-- Mesmo raciocíneo da questão anterior

footer :: (Int, Int) -> String
footer (x,y) = ['+'] ++ (replicate (x) '-') ++ ['+'] ++ (replicate (y) '-') ++ ['+']

-- Exercício 18.

-- Mesmo raciocíneo da questão 16

row :: (Int, Int) -> (String, Int) -> String
row (x,y) (s,n) = ['|'] ++ (complete (x) s) ++ ['|'] ++ (complete (y) (show n)) ++ ['|'] ++ ['\n']

-- Exercício 19.

-- Nesta questão reutilizei das anteriores porém com o acréscimo da chamada recursiva de uma função
-- derivada que criei para percorrer todo o conteúdo de entrada "Table", para que assim possamos
-- adquirir uma tabela completa.

-- Obtive pequenos problemas nesta questão devido a falta de atenção na passagem de parâmetros
-- mas deu tudo certo.

pprintTable :: Table -> String
pprintTable [] = []
pprintTable (x:xs) = header (columnsSize (x:xs)) ++ (pprintTable' (x:xs) (columnsSize (x:xs))) ++ footer (columnsSize (x:xs))

pprintTable' :: Table -> (Int, Int) -> String
pprintTable' [] _ = []
pprintTable' (x:xs) (z,w) = row (z,w) x ++ pprintTable' xs (z,w)

-- Observação: Ao meu ver a prova não estava com uma dificuldade divergente das listas, no inicio
-- me assustei devido ao número de questões e tambem ao azar de travar em algumas específicas.
-- Mas não nego que a prova me tomou horas e horas.

-- Sobre o material de apoio, revisei os capitulos dos livros, analisei alguns códigos no stack
-- Overflow (NÃO COPIEI NADA) e tambem encontrei um curso de Haskell gratuito na Udemy.

-- Link curso: https://www.udemy.com/course/curso-haskell/learn/lecture/4932406#overview
