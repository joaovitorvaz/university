module Main where

main :: IO ()
main = return ()
