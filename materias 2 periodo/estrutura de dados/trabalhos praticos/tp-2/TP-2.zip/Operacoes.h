#ifndef OPERACOES_H
#define OPERACOES_H

#include <stdio.h>
#include <stdlib.h>
#include "Pilha.h"

void insereObj(Pilha* p);

#endif
