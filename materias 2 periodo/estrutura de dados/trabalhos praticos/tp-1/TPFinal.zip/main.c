#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "Morador.h"
#include "Tarefa.h"
#include "Afazer.h"
#include "Republica.h"
#include "Menu.h"

int main(){
    printf("Bem vindo ao Gerenciador de Republica.\n\n");
    mainMenu();
    return 0;
}
