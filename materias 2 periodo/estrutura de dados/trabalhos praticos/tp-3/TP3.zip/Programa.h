#ifndef PROGRAMA_H
#define PROGRAMA_H

#include "Huffman.h"
#include "Hash.h"
#include "Aluno.h"

void atv1();
void atv2();

#endif
