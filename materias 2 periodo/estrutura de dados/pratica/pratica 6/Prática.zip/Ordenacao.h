#ifndef ORDENACAO_H
#define ORDENACAO_H

#include <stdio.h>
#include <stdlib.h>

int Maximo(int *v, int tam);
void CountingSort(int *v, int tam, int expo);
void RadixSort(int *v, int tam);

#endif
