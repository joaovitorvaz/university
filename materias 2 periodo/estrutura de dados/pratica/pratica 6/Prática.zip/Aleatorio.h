#ifndef ALEATORIO_H
#define ALEATORIO_H

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int Aleatorio(int *v, int tam);
void Printar(int *v, int tam);

#endif
