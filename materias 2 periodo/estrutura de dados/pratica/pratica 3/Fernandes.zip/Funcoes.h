#ifndef FUNCAO_H
#define FUNCAO_H

#include <stdio.h>

int SomadeValores(int *vetor, int tam);
void InverteArray(int *vetor, int tam);
int MOD(int x, int y);
int Somatorio(int num);

#endif
