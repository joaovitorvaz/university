#ifndef CASES_H
#define CASES_H

#include <stdio.h>
#include <stdlib.h>

#include "Ordenacao.h"
#include "Valores.h"

void case1Buble(int *v, int tam);
void case2Selection(int *v, int tam);
void case3Merge(int *v, int tam);
void case4Insertion(int *v, int tam);

#endif
