#ifndef VALORES_H
#define VALORES_H

#define T 1000

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void Aleatorio(int *vetor, int tam);
void OrdenadoCresc(int *vetor, int tam);
void OrdenadoDescre(int *vetor, int tam);
void Printar(int *vetor, int tam);
void TempoAtualInicial();
void TempoAtualFinal();

#endif
